-----------------------------
Survey Project Readme manual 
-----------------------------

- Create superuser
'python manage.py createsuperuser'

- Create database : 'survey_db2'

- Run Django Server
'python manage.py runserver'